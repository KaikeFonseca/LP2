﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculoIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxImc.Clear();

            mskbxPeso.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;

            if(Double.TryParse(mskbxPeso.Text, out peso) &&
                Double.TryParse(mskbxAltura.Text, out altura))
            {
                if (altura != 0)
                {
                    imc = peso / Math.Pow(altura,2);
                    imc = Math.Round(imc, 1);
                    mskbxImc.Text = imc.ToString();

                    if (imc <= 18.5)
                    {
                        MessageBox.Show("Magreza");
                    }
                    else if (imc <= 24.9)
                    {
                        MessageBox.Show("Normal");
                    }
                    else if (imc <= 29.9)
                    {
                        MessageBox.Show("Sobrepeso");
                    }
                    else if (imc <= 39.9)
                    {
                        MessageBox.Show("Obesidade");
                    }
                    else
                    {
                        MessageBox.Show("Obesidade Grave");
                    }

                }
                else
                {
                    MessageBox.Show("Valor inválido");
                    mskbxAltura.Clear();
                    mskbxAltura.Focus();
                }

            }
            else
            {
                MessageBox.Show("Valor inválido");
                mskbxPeso.Focus();
            }
        }
    }
}
